import "./App.css";
import Counter from "./Counter";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App">
      <Counter />
    </div>
  );
}

export default App;
