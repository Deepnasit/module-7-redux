import React from "react";

function Home() {
  return (
    <div>
      <h1>Home Page</h1>
      <br />
      <p>Welcome to my portfolio!</p>
    </div>
  );
}

export default Home;
