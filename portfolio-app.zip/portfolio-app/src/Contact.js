import React from "react";

function Contact() {
  return (
    <div>
      <h1>Contact Page</h1>
      <br />
      <p>Get in touch with me via 8487996096</p>
    </div>
  );
}

export default Contact;
